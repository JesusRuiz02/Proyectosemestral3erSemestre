using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosion : MonoBehaviour
{
    [SerializeField] private float radio;

    [SerializeField] private float explosionforce;
    // Start is called before the first frame update

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (CompareTag("Player") || CompareTag("Obstacles"))
        {
         Rigidbody2D _rigidbody2D  = col.GetComponent<Rigidbody2D>();
            Vector2 direction = col.transform.position - transform.position;
            float distance = 1 + direction.magnitude;
            float finalforce = explosionforce / distance;
            _rigidbody2D.AddForce(direction * finalforce);
        }
        Destroy(gameObject);
    }
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, radio);
    }
}
