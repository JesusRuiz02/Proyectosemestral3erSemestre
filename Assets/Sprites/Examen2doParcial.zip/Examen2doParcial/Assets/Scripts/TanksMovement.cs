using UnityEngine;

public class TanksMovement : MonoBehaviour
{
    [SerializeField] private float _velocityX = default;
    [SerializeField] private float _velocityY = default;
    [SerializeField] private Rigidbody2D _rigidbody2D = default;
    [SerializeField] private float _speed = default;
    
    
    
    void Start()
    {
        _rigidbody2D = GetComponent<Rigidbody2D>();
    }
    
    void Update()
    {
        Movement();
    }
    
    private void Movement()
    {
        _velocityX = Input.GetAxis("Horizontal");
        _velocityY = _rigidbody2D.velocity.y;
        _rigidbody2D.velocity = new Vector2(_velocityX * _speed, _velocityY);
    }
}
