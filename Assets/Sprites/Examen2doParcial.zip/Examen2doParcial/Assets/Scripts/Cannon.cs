using Unity.Mathematics;
using UnityEngine;

public class Cannon : MonoBehaviour
{
    [SerializeField] private GameObject _bullet = default;
    [SerializeField] private float _bulletCharge = default;
    [SerializeField] private float _power = default;
    public bool _fire = false;
    [SerializeField] private Transform firepoint = default;
    [SerializeField] private AudioSource explosion;

    void Update()
    {
        var direction = Input.mousePosition - Camera.main.WorldToScreenPoint(transform.position);
        var angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        if (Input.GetMouseButton(0))
        {
            _bulletCharge += Time.deltaTime;
        }

        if (Input.GetMouseButtonUp(0))
        {
            _fire = true;
            explosion.Play();
        }
    }

    private void FixedUpdate()
    {
        if (_fire)
        {
            GameObject missile = Instantiate(_bullet, firepoint.position, firepoint.rotation);
            missile.GetComponent<Rigidbody2D>().AddForce(firepoint.right * _bulletCharge * _power);
            _fire = false;
            _bulletCharge = 0;
        }
    }
    
    
}
