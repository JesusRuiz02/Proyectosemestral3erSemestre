using System;
using System.Collections;
using System.Timers;
using UnityEngine;

public class SystemManager : MonoBehaviour
{
    [SerializeField] private GameObject Player1 = default;
    [SerializeField] private GameObject Player1Move = default;
    [SerializeField] private GameObject Player2 = default;
    [SerializeField] private GameObject Player2Move = default;
    [SerializeField] private GameObject Player1Arrow, Player2Arrow;
    [SerializeField] private bool Turn1 = true;
    private Cannon _cannon;
    [SerializeField] private PlayerTurn playerTurn = PlayerTurn.Player1;
    [SerializeField] private float _timer;
    public enum PlayerTurn
    {
        Player1,
        Player2
    }

    private void Start()
    {
        PlayerTurn playerTurn;
        playerTurn = PlayerTurn.Player1;
        _cannon = GetComponent<Cannon>();
    }

    // Update is called once per frame
    void Update()
    {
        _timer += Time.deltaTime;
        if (playerTurn == PlayerTurn.Player1)
        {
            StartCoroutine(Playersturn(Player2, Player1, Player2Move,Player1Move, Player1Arrow, Player2Arrow ));
        }
        else if (playerTurn == PlayerTurn.Player2)
        {
            StartCoroutine(Playersturn(Player1, Player2, Player1Move, Player2Move, Player2Arrow, Player1Arrow));
        }

        if (Input.GetMouseButtonUp(0))
        {
           _ChangeEnum();
           _timer = 0;
        }
        if (_timer >= 45)
        {
            _ChangeEnum();
            _timer = 0;
        }
    }

    public IEnumerator Playersturn(GameObject PlayerOff, GameObject PlayerOn, GameObject PlayerMoveOff, GameObject PlayerMoveOn, GameObject PlayerOnArrow, GameObject PlayerOffArrow)
    {
       yield return new WaitForSeconds(1f);
       PlayerOff.GetComponent<Cannon>().enabled = false;
       PlayerMoveOff.GetComponent<TanksMovement>().enabled = false;
       PlayerOn.GetComponent<Cannon>().enabled = true;
       PlayerMoveOn.GetComponent<TanksMovement>().enabled = true;
       PlayerOnArrow.SetActive(true);
       PlayerOffArrow.SetActive(false);
       
    }

    private void _ChangeEnum()
    {
        Turn1 = !Turn1;
        if (Turn1)
        {
            playerTurn = PlayerTurn.Player1;
        }
        else if (!Turn1)
        {
            playerTurn = PlayerTurn.Player2;
        }
    }
}
