using System;
using UnityEngine;

public class TankHealth : MonoBehaviour
{
    [SerializeField] public float _health = 100;
    void Update()
    {
        if (_health <= 0)
        {
            Destroy(gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        _health -= 34;
        Debug.Log("Le di");
    }
}
